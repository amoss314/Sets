package umsl.edu.sets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Set;
import java.util.TreeSet;

public class App {

	public static void main(String[] args) throws IOException {

		App app = new App();
		app.mypatientHashset();

	}

	public void mypatientHashset() throws IOException {

		Set<Patients> patientHashset = new TreeSet<Patients>(new MyComparator());

		for (int i = 0; i < 10; i++) {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(isr);

			System.out.println("Please, enter patient's ID.");
			int ID = br.read();
			// I can't get the INT to read correctly and print it out right
			System.out.println("Please, enter patient's name.(John Doe)");
			String FirstName = br.readLine();
			String LastName = br.readLine();
			System.out.println("Please, enter patient's Illness.");
			String Illness = br.readLine();
			System.out.println("Please, enter any notes about patient.");
			String Notes = br.readLine();

			patientHashset.add(new Patients(ID, FirstName, LastName, Illness, Notes));

			for (Patients patients : patientHashset) {

				System.out.println(patients.patientID + " " + patients.firstName + " " + patients.lastName + " "
						+ patients.illness + " " + patients.notes);

			}
		}
	}
}
