package umsl.edu.sets;

import java.util.Comparator;

public class MyComparator implements Comparator<Patients> {

	public int compare(Patients arg0, Patients arg1) {

		return arg0.getLastName().compareTo(arg1.getLastName());
	}

}
